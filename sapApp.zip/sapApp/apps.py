from django.apps import AppConfig


class SapappConfig(AppConfig):
    name = 'sapApp'
